<?php
$conn = new mysqli('sql208.epizy.com','epiz_32939749','BZ97xAMUIHPLb','epiz_32939749_forestQuiz',"3306") or die(mysqli_error());
if ($conn -> connect_errno) {
    
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}
?>
