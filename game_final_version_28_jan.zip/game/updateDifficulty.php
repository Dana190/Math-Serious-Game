<?php
include("session.php");
$_SESSION["easy_level"]=$_POST["level"];
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
?>