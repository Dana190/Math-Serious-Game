<?php
include('db/dbcon.php');

$username = $_POST['username'];
$pass = $_POST['password'];
$gender = $_POST['gender'];

//Check first if there are similar usernames registered in database
$q = mysqli_query($conn,"select * from users where username='$username' ")or die('Error, query failed');
$num_rows=mysqli_num_rows($q);

if($num_rows > 0){
    $response['status'] = 'multi-user';
    header('Content-type: application/json');
    echo json_encode($response);
}
else{
$stmt = $conn->prepare("insert into users(username,password,gender) 
		values 
		(?,?,?)")or die('Error, query failed');
		
$stmt->bind_param("sss",$username,$pass,$gender);
$stmt->execute();
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
}		
?>