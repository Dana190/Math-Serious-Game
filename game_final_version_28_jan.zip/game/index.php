<?php 
include('session.php');
include "db/dbcon.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasure Hunt: Majd's Adventurous Quest to find the Mystery Box</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- FontAweome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="script/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
    <link rel="script/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" />
    <!-- jQuery Ajax Library -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style>
.profile {
  vertical-align: middle;
  width: 150px;
  height: 150px;
  border-radius: 1%;
  border-color: #007bff;
  border-width: 5px;
}
h5{
font-size:16px;
}
.tooltip1 {
    
    position: absolute;
    display: inline-block;
    border-bottom: 1px dotted black;
    right: 4rem;
  }

  .tooltip1 img {
      width: 40px;
  }

  .tooltip1 .tooltiptext1 {
    visibility: hidden;
    width: max-content;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    right: 0;
    top: 50px;
    padding: 10px
}
  
  /*.tooltip1:click .tooltiptext1 {
    visibility: visible;
  }*/
body {  
        background:lightblue;
        background-image: url('images/bg.jpg');
        height: 100%;
        width:100%;
        background-position: center;
        background-size:cover;
       
 }
   .image-container {
    position: relative;
  }
  footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  /* other styles */
}
  .image-overlay {
    position: absolute;
    top: 15;
    left: 90;
    bottom: 0;
    width: 30%;
    height: 20%;
    //right: 0;
    display: flex;
    //align-items: center;
    //justify-content: center;
    color: black;
    background-color: rgba(0, 0, 0, 0);
    z-index: 1;
  }
    .image-overlay2 {
    position: absolute;
    top: 45;
    left: 90;
    bottom: 0;
    width: 30%;
    height: 20%;
    //right: 0;
    display: flex;
    //align-items: center;
    //justify-content: center;
    color: green;
    background-color: rgba(0, 0, 0, 0);
    z-index: 1;
  }
    </style>
    <script>
    function toggleAudio(){
var audioElm = document.getElementById('music'); 
audioElm.muted = !audioElm.muted;
    }
    // Save the score to localStorage
function saveScore(score) {
  localStorage.setItem('score', score);
}

// Retrieve the score from localStorage
function getScore() {
  return localStorage.getItem('score');
}

// Update the score
function updateScore(score) {
  saveScore(score);
  // Update the score display
  document.getElementById('score').innerHTML = "Score: "+score;
}

function decreaseScore() {
 var score=getScore();
 if(score>1){
 score--;
 saveScore(score);
  // Update the score display
  document.getElementById('score').innerHTML = "Score: "+score;
 }
}
function resetHint() {
  localStorage.setItem('hints_used', 0);
}

// Retrieve the score from localStorage
function getHintCount() {
  return localStorage.getItem('hints_used');
}

// Update the score
function incrementHint() {
    var count=getHintCount();
    count++;
  localStorage.setItem('hints_used', count);
  // Update the score display
  /*
  if(count>=3){
document.getElementById('hint_counter').innerHTML = "No Hints Left!";
document.getElementById('hint_counter').style.color="red";
document.getElementById('hint').style.visibility = 'hidden';

  }
  else */
  document.getElementById('hint_counter').innerHTML = count +" Hints Used";
}
    </script>
</head>
<body>

<!-- start Quiz button -->
<div class="start_btn"><button>Click Here to Embark on A wonderful Journey</button></div>
<?php 
            //Load Progress
            $q = mysqli_query($conn,"select * from users where username='$user_username' LIMIT 1") or die('Error, Select query failed');
            $r = mysqli_fetch_array($q);
            $prog = $row['progress'];
            $score=$row["score"];
            ?>
<div style="position:absolute;left:20;bottom:10"><img src="images/mute.png" width="60px" height="60px" onclick="toggleAudio()"/></div>
<div style="position:absolute;left:35%;bottom:5">
    <h6>All Freepik Images used are CopyRighted</h6>
  </div>
<div class="image-container"><img src="images/score.png" />
 <div class="image-overlay">
    <h4 id="score">Score: 0</h4>

  </div>

<div class="image-overlay2">
    <h6 id="hint_counter">0 Hints Used</h6>
</div>
</div>
<!-- Info Box => Game Story -->
<div class="info_box container my-4 align-items-center justify-content-center" id="info_box">
        <div class="info-title"><span>Prologue:</span></div>
        <div class="info-list">

	 <div class="info_text" style="<?php if($gender=='male') echo 'display:block'; else echo 'display:none' ?>">
           
        </div>
       <div class="info_textF" style="<?php if($gender=='female') echo 'display:block'; else echo 'display:none' ?>">
           
        </div> 
        </div>
        <div class="buttons">
            <button class="quit">Exit Journey</button>
            <button class="restart continue" data-level="1" data-quesid="1" >Start</button>
            
            <button class="restart continue" data-quesid="<?php echo $prog; ?>" >Load</button>
        </div>
    </div>
	
<form id="quiz-form" class="quiz-form" style="display:block">

<?php 
$query = mysqli_query($conn,"select * from questions") or die('Error, Select query failed');
while($row = mysqli_fetch_array($query)){
    
    $ques_id = $row['ques_id'];
    $level=$row['level'];
    $level_part=$row['level_part'];
    $isFinalQues=$row['is_final_ques'];
    if(isset($row['hint']) && $row['hint']!=""){
        $hint=$row['hint'];
    }
    else $hint="No Hint Provided!";
    $prev_ques=$row['prev_ques_id'];
    $next_ques=$row['next_ques_id'];
    
    $query2 = mysqli_query($conn,"select * from questions where ques_id='$next_ques' Limit 1");
    $row2=mysqli_fetch_array($query2);
    $next_level=$row2["level"];

    $query3 = mysqli_query($conn,"select * from questions where ques_id='$prev_ques' Limit 1");
    $row3=mysqli_fetch_array($query3);
    $prev_level=$row3["level"];
/*
    $difficulty=1; // 0 means show easy questions and 1 means show hard questions (default)
    if(isset($_SESSION["easy_level"]) && $_SESSION["easy_level"]==$level){
        $difficulty=0;
    }*/

    if($gender=="male"){
       
    $question_hard=$row['questionM_hard'];
    $story_hard=$row['storyM_hard'];
     
$question=$row['questionM'];
    $story=$row['storyM'];
        
    }
    else {
        
    $question_hard=$row['questionF_hard'];
    $story_hard=$row['storyF_hard'];
        
$question=$row['questionF'];
    $story=$row['storyF'];
        
    }
   
$choices_hard=$row['choices_hard'];
    $array_choices_hard = explode(',', $choices_hard);
    $answer_hard=$row['answer_hard'];
   
$choices=$row['choices'];
    $array_choices = explode(',', $choices);
    $answer=$row['answer'];
    
    

echo "<div class='quiz_box align-items-center justify-content-center'  id='quiz_box"; echo $ques_id; echo "' >
<header>
            <div class='title'>Level $level </div>           
</header>
        <section>         
                <div class='question bg-white p-3 border-bottom'>
                    <div class='d-flex flex-row align-items-center question-title'>                    
                        <h5 class='mt-1 ml-2'>";
$isStory=false;

if($story!=""){
    
    $isStory=true;
  
    echo $story;
}
else echo $question;

echo "</h5>
                    </div>
                    
                    ";
if($story===""){
    echo "<div class='tooltip1' id='hint"; echo $ques_id; echo "' style='visibility:visible'>
                            <img src='images/hint.png' class='lamp' id='lamp' name='lamp' data-next='".$next_level."' data-img='"; echo $ques_id; echo "'width='40px' height='40px'>
                          <span id='hintText"; echo $ques_id; echo "'class='tooltiptext1' style='visibility:hidden'>".$hint."</span>
                          </div>";
}
                 if($choices!=""){ 
                    for($i=0;$i<count($array_choices);$i++){
                  
           echo "<div class='ans ml-2'>
                        <label class='radio'> <input type='radio' name='"; echo $ques_id; echo "' id='"; echo $ques_id; echo "' value='";
                        if($answer == $i) echo "true"; else echo "false"; echo "' > <span>";
                        echo $array_choices[$i]; echo "</span>
                        </label>
                    </div>";
                  
                   
                    }
                   } 
               echo " </div>
                <div class='d-flex flex-row justify-content-between align-items-center p-3 bg-white'> ";
                if($prev_ques!=0){
                echo "<button class='btn btn-primary d-flex align-items-center btn-danger back' data-nextid='";echo $next_ques; echo "' data-previd='";echo $prev_ques; echo "' data-levelid='";echo $prev_level; echo "' data-quesid='";echo $ques_id; echo "' data-next='".$next_level."' data-prev='".$prev_level."' data-artid='";echo $prev_ques; echo "' data-isStory='";echo $isStory; echo "' type='button'><i class='fa fa-angle-left mt-1 mr-1'></i>&nbsp;previous</button>";
                } 
               if($isFinalQues==0){ 
               
                echo "<button class='btn btn-primary border-success align-items-center btn-success next' data-nextid='";echo $next_ques; echo "' data-previd='";echo $prev_ques; echo "' data-levelid='";echo $next_level; echo "' data-quesid='";echo $ques_id; echo "' data-next='".$next_level."'data-prev='".$prev_level."'  data-artid='";echo $next_ques; echo "' onclick='' data-isStory='";echo $isStory; echo "' type='button' >Next<i class='fa fa-angle-right ml-2'></i></button>";
                 } 
                 else if($isFinalQues==1){
                    echo " <input type='reset' class='reset' value='reset' style='display:none'>";
                     echo "<button class='btn btn-primary border-success align-items-center btn-success finish' data-nextid='";echo $next_ques; echo "' data-previd='";echo $prev_ques; echo "' data-levelid='";echo $level; echo "' data-quesid='";echo $ques_id; echo "' data-next='".$next_level."' data-prev='".$prev_level."'  data-artid='";echo $next_ques; echo "' data-isStory='";echo $isStory; echo "' type='button' >Finish<i class='fa fa-angle-right ml-2'></i></button>";
                 }
                echo "</div>
        </section>
</div>";

/****Hard Version*****/
echo "<div class='quiz_box align-items-center justify-content-center'  id='quiz_box_hard"; echo $ques_id; echo "' >
<header>
            <div class='title'>Level $level </div>           
</header>
        <section>         
                <div class='question bg-white p-3 border-bottom'>
                    <div class='d-flex flex-row align-items-center question-title'>                    
                        <h5 class='mt-1 ml-2'>";
$isStory=false;

if($story!=""){
    
    $isStory=true;
  
    echo $story_hard;
}
else echo $question_hard;

echo "</h5>
                    </div>
                    
                    ";
if($story===""){
   echo "<div class='tooltip1' id='hint"; echo $ques_id; echo "' style='visibility:visible'>
                            <img src='images/hint.png' class='lamp_hard' id='lamp' name='lamp' data-next='".$next_level."' data-img='"; echo $ques_id; echo "'width='40px' height='40px'>
                          <span id='hintText_hard"; echo $ques_id; echo "'class='tooltiptext1' style='visibility:hidden'>".$hint."</span>
                          </div>";
}
                 if($choices_hard!=""){ 
                    for($i=0;$i<count($array_choices_hard);$i++){
                  
           echo "<div class='ans ml-2'>
                        <label class='radio'> <input type='radio' name='"; echo $ques_id; echo "' id='"; echo $ques_id; echo "' value='";
                        if($answer_hard == $i) echo "true"; else echo "false"; echo "' > <span>";
                        echo $array_choices_hard[$i]; echo "</span>
                        </label>
                    </div>";
                  
                   
                    }
                   } 
               echo " </div>
                <div class='d-flex flex-row justify-content-between align-items-center p-3 bg-white'> ";
                if($prev_ques!=0){
                echo "<button class='btn btn-primary d-flex align-items-center btn-danger back' data-nextid='";echo $next_ques; echo "' data-previd='";echo $prev_ques; echo "' data-levelid='";echo $prev_level; echo "' data-quesid='";echo $ques_id; echo "' data-next='".$next_level."' data-prev='".$prev_level."' data-artid='";echo $prev_ques; echo "' data-isStory='";echo $isStory; echo "' type='button'><i class='fa fa-angle-left mt-1 mr-1'></i>&nbsp;previous</button>";
                } 
               if($isFinalQues==0){ 
               
                echo "<button class='btn btn-primary border-success align-items-center btn-success next' data-nextid='";echo $next_ques; echo "' data-previd='";echo $prev_ques; echo "' data-levelid='";echo $next_level; echo "' data-quesid='";echo $ques_id; echo "' data-next='".$next_level."' data-prev='".$prev_level."' data-artid='";echo $next_ques; echo "' onclick='' data-isStory='";echo $isStory; echo "' type='button' >Next<i class='fa fa-angle-right ml-2'></i></button>";
                 } 
                 else if($isFinalQues==1){
                    echo " <input type='reset' class='reset' value='reset' style='display:none'>";
                     echo "<button class='btn btn-primary border-success align-items-center btn-success finish' data-nextid='";echo $next_ques; echo "' data-previd='";echo $prev_ques; echo "' data-levelid='";echo $level; echo "' data-quesid='";echo $ques_id; echo "' data-next='".$next_level."' data-prev='".$prev_level."' data-artid='";echo $next_ques; echo "' data-isStory='";echo $isStory; echo "' type='button' >Finish<i class='fa fa-angle-right ml-2'></i></button>";
                 }
                echo "</div>
        </section>
</div>";
}//loop

?>
</form>


<div class="result_box container my-4 align-items-center justify-content-center">
        <div class="icon">
            <i class="fas fa-crown"></i>
        </div>
        <div class="complete_text">Congrats! 🎉</div>
        <div class="complete_text" id="score_finish"></div>
        <div class="complete_text" id="hint_finish"></div>
        <div class="score_text">
           
        </div>
		<!--<center><img src="images/money.png" width="100px"/></center>-->
		<div class="main">
 <form id="rating-form">
<span class="rating-star">
    <input type="radio" name="rating" value="5"><span class="star"></span>
 
    <input type="radio" name="rating" value="4"><span class="star"></span>
 
    <input type="radio" name="rating" value="3"><span class="star"></span>
 
    <input type="radio" name="rating" value="2"><span class="star"></span>
 
    <input type="radio" name="rating" value="1"><span class="star"></span>
</span>
</form>
    <p>Like the Game! Rate Us Please</p>
 </div> 
        <div class="buttons">
            <button class="restart">Restart Game</button>
            <button class="quit">Quit Game</button>
        </div>
    </div>
   
    <!-- Next Question,Previous Question, Calculate Result & Send it to php-->
    <script>
			jQuery(document).ready(function($){
			   $('.continue').click(function() {
				var elem = $(this);
				var first_level="quiz_box"+elem.attr('data-quesid');
				document.getElementById("info_box").classList.remove("activeInfo"); //hide info box
	            document.getElementById(first_level).classList.add("activeQuiz"); //show quiz box
	            saveScore(0);
                resetHint();
                const answeredQuestions = [];
                localStorage.setItem('answered', JSON.stringify(answeredQuestions));
                const hintedQuestions = [];
                localStorage.setItem('hinted', JSON.stringify(hintedQuestions));
                localStorage.setItem('easy_level',0);
                var level=elem.attr('data-level');
                if(level!=null){
                             $("body").css("background-image", "url(images/bg" + level + "-min.jpg)");  
                }
				
						
            });
				$('.next').click(function() { 
				    var elem = $(this);
				    var level=elem.attr('data-levelid');
				    var id=elem.attr('data-quesid');
				    var next=elem.attr('data-artid');
				    var current="quiz_box"+elem.attr('data-quesid');
                    var current_hard="quiz_box_hard"+elem.attr('data-quesid');
				    var next_id="quiz_box"+elem.attr('data-nextid');
                    var next_level=elem.attr('data-next');
                    var next_hard_id="quiz_box_hard"+elem.attr('data-nextid');
				    var prev_id="quiz_box"+elem.attr('data-previd');
                    var prev_hard_id="quiz_box_hard"+elem.attr('data-previd');
				    var isStory=elem.attr('data-isStory');
				    var user_answer=$("input[name="+id+"]:checked").val();
				   //alert(prev_id);
                   //Now calculate score:
                   var score=parseInt(getScore());
                   score=score+1;
				    /*****************************/
				    if(user_answer=="true"){
				        
				        $.ajax({
						type: "POST",
						url: "updateProgress.php",
						dataType: "json",
						data: {"progress":next,"score":score},
						success: function(data){
						  
						 playMusicCorrect();
                         //set score in cookies
                        // Retrieve the array from local storage
                        let storedArray = JSON.parse(localStorage.getItem('answered'));
                        const elementIndex = storedArray.indexOf(id);
                        if (elementIndex === -1) {
                        // Add the new element to the array
                        storedArray.push(id);

                            // Store the updated array back in local storage
                        localStorage.setItem('answered', JSON.stringify(storedArray));
                        
                        updateScore(score);
                        }
                        // else this question is visited previously
                        let easylevel=localStorage.getItem('easy_level');
                        
                        document.getElementById(current).classList.remove("activeQuiz");
                        document.getElementById(current_hard).classList.remove("activeQuiz");
                        
                        if(easylevel==next_level){
			             document.getElementById(next_id).classList.add("activeQuiz");
                        }
                        else{
                        
			            document.getElementById(next_hard_id).classList.add("activeQuiz");
                        }
						  //Now Change Background
				        $("body").css("background-image", "url(images/bg" + level + "-min.jpg)");  
						},
						error: function() {
                        alert("Error Connecting Database!");
                        }
				    });    
				        
				       
			            
				   }
				   else 
				    if(user_answer=="false"){
			            playMusicFalse();
                        document.getElementById('hint'+id).style.visibility = 'visible';
                        
	               }
	               else if (isStory){
	                    $.ajax({
						type: "POST",
						url: "updateProgress.php",
						dataType: "json",
						data: {"progress":next},
						success: function(data){
						 document.getElementById(current).classList.remove("activeQuiz");
                        document.getElementById(current_hard).classList.remove("activeQuiz");
                        let easylevel=localStorage.getItem('easy_level');
                        if(easylevel==next_level){
			             document.getElementById(next_id).classList.add("activeQuiz");
                        }
                        else{
                        
			            document.getElementById(next_hard_id).classList.add("activeQuiz");
                        }
						 //Now Change Background
				        $("body").css("background-image", "url(images/bg" + level + "-min.jpg)");   
						},
						error: function() {
                        alert("Error Connecting Database!");
                        }
				    });
	               }
	             
				    /****************************/
				    
            });


            $('.lamp').click(function() {
				    var elem = $(this);
				    
				    var id=elem.attr('data-img');
                    var next_level=elem.attr('data-next');
                    // Retrieve the array from local storage
                        let storedArray = JSON.parse(localStorage.getItem('hinted'));
                        const elementIndex = storedArray.indexOf(id);
                        if (elementIndex === -1) {
                        // Add the new element to the array
                        storedArray.push(id);

                            // Store the updated array back in local storage
                        localStorage.setItem('hinted', JSON.stringify(storedArray));
                        
                        incrementHint();
                        localStorage.setItem("easy_level",next_level);
                        }
				    /*****************************/
           /* $.ajax({
						type: "POST",
						url: "updateDifficulty.php",
						dataType: "json",
						data: {"level":next_level},
						
				    });
*/
                
  var hint = $('#hintText' + id);

  if (hint.css('visibility') === 'hidden') {
    hint.css('visibility', 'visible');
  } else {
    hint.css('visibility', 'hidden');
  }
  
	               
            });
 $('.lamp_hard').click(function() {
				    var elem = $(this);
				    
				    var id=elem.attr('data-img');
                    var next_level=elem.attr('data-next');
                    // Retrieve the array from local storage
                        let storedArray = JSON.parse(localStorage.getItem('hinted'));
                        const elementIndex = storedArray.indexOf(id);
                        if (elementIndex === -1) {
                        // Add the new element to the array
                        storedArray.push(id);

                            // Store the updated array back in local storage
                        localStorage.setItem('hinted', JSON.stringify(storedArray));
                        
                        incrementHint();
                        localStorage.setItem("easy_level",next_level);
                        }
				    /*****************************/
       //For Hard Version:
    var hint = $('#hintText_hard' + id);

  if (hint.css('visibility') === 'hidden') {
    hint.css('visibility', 'visible');
  } else {
    hint.css('visibility', 'hidden');
  }
  
	               
            });

       
			$('.back').click(function() {
				    var elem = $(this);
				    var level=elem.attr('data-levelid');
                    var prev_level=elem.attr('data-prev');
				    var id="quiz_box"+elem.attr('data-artid');
				    var current="quiz_box"+elem.attr('data-quesid');
                    var current_hard="quiz_box_hard"+elem.attr('data-quesid');
				    var prev_id="quiz_box"+elem.attr('data-previd');
                    var prev_hard_id="quiz_box_hard"+elem.attr('data-previd');
				    var isStory=elem.attr('data-isStory');
				    /*****************************/
                   let easylevel=localStorage.getItem('easy_level');
                        
                        document.getElementById(current).classList.remove("activeQuiz");
                        document.getElementById(current_hard).classList.remove("activeQuiz");
                        
                        if(easylevel==prev_level){
			             document.getElementById(prev_id).classList.add("activeQuiz");
                        }
                        else{
                        
			            document.getElementById(prev_hard_id).classList.add("activeQuiz");
                        }
                   	               
				    /****************************/
				    //Now Change Background
				    $("body").css("background-image", "url(images/bg" + level + "-min.jpg)");
            });
            $('.finish').click(function() {
				    var elem = $(this);
				    var id=elem.attr('data-quesid');
				    var next=elem.attr('data-artid');
				     var current="quiz_box"+elem.attr('data-quesid');
                     var current_hard="quiz_box_hard"+elem.attr('data-quesid');
				    var next_id="quiz_box"+elem.attr('data-artid');
				    var prev_id="quiz_box"+elem.attr('data-previd');
				    var isStory=elem.attr('data-isStory');
				    var user_answer=$("input[name="+id+"]:checked").val();
				   var score=parseInt(getScore());
                   score=score+1;
                   //Reset HTML Input:
                   $(this).closest("div").find(".reset").click();
				    /*****************************/
				    if(user_answer=="true"){
				        $.ajax({
						type: "POST",
						url: "updateProgress.php",
						dataType: "json",
						data: {"progress":1},
						success: function(data){
						    playMusicCorrect();
                            let storedArray = JSON.parse(localStorage.getItem('answered'));
                        const elementIndex = storedArray.indexOf(id);
                        if (elementIndex === -1) {
                        // Add the new element to the array
                        storedArray.push(id);

                            // Store the updated array back in local storage
                        localStorage.setItem('answered', JSON.stringify(storedArray));
                        
                        updateScore(score);
                        }
                        var final_score=parseInt(getScore());
                        var final_hints=parseInt(getHintCount());
                          document.getElementById('score_finish').innerHTML = "Your Final score is "+final_score;
                          if(final_hints<1){
                           document.getElementById('hint_finish').innerHTML = "GREAT! You didn't use any hint"; 
                           document.getElementById('hint_finish').style.color="green";        
                          }
                          else {
                        document.getElementById('hint_finish').innerHTML = "OOOPS! You have used "+final_hints+ " hints";
                        document.getElementById('hint_finish').style.color="red";
                          }
                            //reset difficulty
                            localStorage.clear();
                            localStorage.setItem("easy_level",0);//reset all questions to become hard by default
                            
						  document.getElementById(current).classList.remove("activeQuiz");
                          document.getElementById(current_hard).classList.remove("activeQuiz");

                          
			          <?php if($gender=="male") { 
			           echo 'showResult()';
			           }
			           else echo 'showResultF()';
			           ?>
						    
						},
						error: function() {
                        alert("Error Connecting Database!");
                        }
				    });
				      
				   }
				   else 
				    if(user_answer=="false"){
			            playMusicFalse();
                       
	               }
	               else if (isStory){
	                   $.ajax({
						type: "POST",
						url: "updateProgress.php",
						dataType: "json",
						data: {"progress":1},
						success: function(data){
						  document.getElementById(current).classList.remove("activeQuiz");
                          
                    var final_score=parseInt(getScore());
                        var final_hints=parseInt(getHintCount());
                          document.getElementById('score_finish').innerHTML = "Your Final score is "+final_score;
                          if(final_hints<1){
                           document.getElementById('hint_finish').innerHTML = "GREAT! You didn't use any hint"; 
                           document.getElementById('hint_finish').style.color="green";        
                          }
                          else {
                        document.getElementById('hint_finish').innerHTML = "OOOPS! You have used "+final_hints+ " hints";
                        document.getElementById('hint_finish').style.color="red";
                          }
			          <?php if($gender=="male") { 
			           echo 'showResult()';
			           }
			           else echo 'showResultF()';
			           ?>
						    
						},
						error: function() {
                        alert("Erro Connecting Database!");
                        }
				    });
	                   
	                  
	               }
	             
				    /****************************/
            });
		});

   
    </script>
    <!-- Inside this JavaScript file I've coded all Quiz Codes -->
    <script src="js/script.js"></script>
    <!-- Rating Star -->
	<script>
	$('#rating-form').on('change','[name="rating"]',function(){
    $('#selected-rating').text($('[name="rating"]:checked').val());
    var rating=$('[name="rating"]:checked').val();
    $.ajax({
						type: "POST",
						url: "updateRating.php",
						dataType: "json",
						data: {"rating":rating},
						success: function(data){
						    
						},
				    });
        });
	</script>
	   <!-- Background Music -->
    <audio id="music" src="music/bg.mp3" autoplay loop></audio>
   
</body>

</html>
