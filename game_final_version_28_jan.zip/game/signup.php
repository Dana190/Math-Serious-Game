<?php 
include "db/dbcon.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasure Hunt: Majd's Adventurous Quest to find the Mystery Box</title>
    <link rel="stylesheet" href="style.css">
    <!-- FontAweome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="script/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
     <!-- jQuery Ajax Library -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
<style>
.profile {
  vertical-align: middle;
  width: 150px;
  height: 150px;
  border-radius: 1%;
  border-color: #007bff;
  border-width: 5px;
}
h5{
font-size:16px;
}
body {  
        background:lightblue;
        background-image: url('images/login.png');
        height: 100%;
        width:100%;
        background-position: center;
        background-size:cover;
       
 }
    </style>
    
</head>
<body>
<!-- Choose Username -->
<div class="avatar" id="user" >
<header>
    <div class="title" style="text-align:center;font-size:25px;" ><strong>Create Character</strong></div>      
</header>

        <section>
               <div class="info-list">
	<div class="info">
                <table>
                    <tr><td>Username</td></tr>
				  <tr>
				    
				  <td><input type="text" name="username" id="username"  placheholder="Username" value=""/> </td></tr>
				  <tr><td>Password</td></tr>
				  <tr><td><input type="password" name="password" id="password"  min=6 max=12 placheholder="Password" value="" /></td>
				  </tr>
				</table>
                    
    </div>
				</div>
                <div class="d-flex flex-row justify-content-between align-items-center p-3 bg-white pager">
                    <button class="btn btn-primary border-success align-items-center btn-success continue" type="button">Continue<i class="fa fa-angle-right ml-2"></i></button>
                
    </div>
                
    </section>
</div>

<!-- Choose Character -->
<div class="avatar" id="avatar" >
<header>
    <div class="title" style="text-align:center;font-size:25px;" ><strong>Choose Your Avatar</strong></div>      
</header>

        <section>
               <div class="info-list">
	<div class="info">
                <table>
				  <tr>
				  <td> <img src="images/male.png" alt="Avatar" class="profile img-responsive"> </td>
				  <td> <div style="width:20px"></div> </td>
				  <td> <img src="images/female.png" alt="Avatar" class="profile img-responsive"> </td>
				  </tr>
				</table>
                    
    </div>
				</div>
                <div class="d-flex flex-row justify-content-between align-items-center p-3 bg-white pager"><button class="btn btn-primary d-flex align-items-center btn-danger male" type="button">&nbsp;Male&nbsp;<i class="fa fa-angle-right mt-1 mr-1"></i></button>
                <button class="btn btn-primary border-success align-items-center btn-success female" type="button" >Female<i class="fa fa-angle-right ml-2"></i></button>
                
    </div>
                
    </section>
</div>


    <!-- Next Question,Previous Question, Calculate Result & Send it to php-->
    <script>
    let user=document.querySelector("#user");
    user.classList.add("activeAvatar");
	user.style.display = "block";
    /*
    let avatar=document.querySelector("#avatar");
    avatar.classList.add("activeAvatar");
	avatar.style.display = "block";*/
			jQuery(document).ready(function($){
			   
				$('.continue').click(function() {
				    
				    var elem = $(this);
				    var username= $("[name='username']").val();
				    var password= $("[name='password']").val();
				   
				    /*****************************/
				    if(username =="" || password ==""){
				       //document.getElementById(prev_id).classList.remove("activeQuiz");
			           //document.getElementById(next_id).classList.add("activeQuiz");
			            playMusicFalse();
				   }
				   else {
				    //Hide User and Show Avatar:
				    user.classList.add("activeAvatar");
	                user.style.display = "none";
	                
				    let avatar=document.querySelector("#avatar");
                    avatar.classList.add("activeAvatar");
	                avatar.style.display = "block";
	               }
	             
				    /****************************/
            });
	        
	        $('.male').click(function() {
				    
				    var elem = $(this);
				    var username= $("[name='username']").val();
				    var password= $("[name='password']").val();
				   
				    /*****************************/
				    $.ajax({
						type: "POST",
						url: "createAccount.php",
						dataType: "json",
						data: {"username":username,"password":password,"gender":"male"},
						success: function(data){
						    if(data.status == 'multi-user'){
						        alert("Username Already Taken! Choose Another");
						        window.location = 'signup.php';
						    }
						    else {
						alert("Player Successfully  Created");
						window.location = 'login.php'; 
						    }
						},
							error: function() {
                        alert("There was an error. Try again please!");
                        }
				    });
				    /****************************/
            });
            $('.female').click(function() {
				    
				    var elem = $(this);
				    var username= $("[name='username']").val();
				    var password= $("[name='password']").val();
				   
				    /*****************************/
				    $.ajax({
						type: "POST",
						url: "createAccount.php",
						dataType: "json",
						data: {"username":username,"password":password,"gender":"female"},
						success: function(data){
						   if(data.status == 'multi-user'){
						        alert("Username Already Taken! Choose Another");
						        window.location = 'signup.php'; 
						    }
						    else {
						alert("Player Successfully  Created");
						window.location = 'login.php'; 
						    }  
						},
						error: function() {
                        alert("There was an error. Try again please!");
                        }
				    });
				    /****************************/
            });
            
		});

   
    </script>
    <!-- Inside this JavaScript file I've coded all Quiz Codes -->
    <script src="js/script.js"></script>

</body>
</html>
