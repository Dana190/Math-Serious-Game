<?php
include_once('db/dbcon.php');
session_start();
function test_input($data) {
	
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

if ($_SERVER["REQUEST_METHOD"]== "POST") {
	
	$username = test_input($_POST["username"]);
	$password = test_input($_POST["password"]);
	$stmt = $conn->prepare("SELECT * FROM users where username='$username' AND password='$password' Limit 1");
	$stmt->execute();
	$result = $stmt->get_result();
		
	$row = mysqli_fetch_array($result);
	$num_row = mysqli_num_rows($result);
	
		
		if($num_row == 1 && $row["username"]!=="admin") {
		    $_SESSION['id']=$row['user_id'];
			header("Location: index.php");
		}
		else if($num_row == 1 && $row["username"]=="admin") {
		    $_SESSION['id']=$row['user_id'];
			header("Location: admin/index.php");
		}
		else {
			echo "<script language='javascript'>";
			echo "alert('Error In Credentials'); window.location='login.php';";
			echo "</script>";
			die();
		}

}

?>
