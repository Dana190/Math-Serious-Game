<?php
include('db/dbcon.php');
include('session.php');
if($user_username != null){
$prog = $_POST['progress'];
$score=$_POST["score"];
$stmt = $conn->prepare("update users set progress = ? ,score= ? where username='$user_username' ")or die('Error, query failed');
		
$stmt->bind_param("ii",$prog,$score);
$stmt->execute();
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
}
?>