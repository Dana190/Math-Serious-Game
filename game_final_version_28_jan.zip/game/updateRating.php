<?php
include('db/dbcon.php');
include('session.php');
if($user_username != null){
$rate = $_POST['rating'];

$stmt = $conn->prepare("update users set rating = ? where username='$user_username' ")or die('Error, query failed');
		
$stmt->bind_param("i",$rate);
$stmt->execute();
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
}
?>