<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href=
"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Treasure Hunt: Majed's Adventurous Quest to find the Mystery Box</title>
    <style>
        body {
        background-image: url('images/login.png') ;
        height: 100%;
        width:100%;
        background-size:cover;
       
 }
    </style>
</head>
  
<body>
    <form action="validate.php" method="post">
        <div class="login-box">
<center><h1>Welcome</h1></center>
  <center>
            <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
                <input type="text" placeholder="Username"
                         name="username" value="">
            </div>
  </center>
  <center>
            <div class="textbox">
                <i class="fa fa-lock" aria-hidden="true"></i>
                <input type="password" placeholder="Password"
                         name="password" value="">
            </div>
  </center>
            <center><input class="button" type="submit"
                     name="login" value="Sign In">
                     </center>
                     <center><a href="signup.php"> Don't Have Account !</a></center>
                     <div></div>
        </div>
    </form>
</body>
  
</html>