//selecting all required elements
const start_btn = document.querySelector(".start_btn button");
const info_box = document.querySelector(".info_box");
const avatar = document.querySelector(".avatar");
const exit_btn = document.getElementById("info_box").querySelector(".buttons .quit");
const continue_btn = document.getElementById("info_box").querySelector(".buttons .restart");
const quiz_box = document.querySelector(".quiz_box");
const result_box = document.querySelector(".result_box");
const option_list = document.querySelector(".option_list");

// if startQuiz button clicked
start_btn.onclick = ()=>{
    start_btn.style.display = "none";
    document.getElementById("info_box").classList.add("activeInfo");
    document.getElementById('quiz-form').style.display = 'block';
    
    const infoText = document.getElementById("info_box").querySelector(".info_text");
    const infoTextF = document.getElementById("info_box").querySelector(".info_textF");

    let infoTag = "<span>Once upon a time, there lived a young boy with his mother on the outskirts of a small and peaceful village called Tomako. On a clear day early in the summer, Dalia, Majd’s mother, was preparing a cake for Majd’s birthday when the mail arrived with a bunch of letters. Majd sifted through the advertisements to pick up one special envelope addressed to him by name. Dalia asked Majd to open the envelope carefully and read it out loud. Majd did so, and read:</br>"+ 
"'My beloved Majd,"+
"It has been two years since we last celebrated your birthday together. You, your mom, and I. I am getting my work finished and can’t wait to see you both again. I still have that wool necklace that you made for me to keep me safe. I wear it all the time. Unfortunately, I am not going to make it in time for your birthday. However, I have a gift for you stashed in a chest under ‘The Sheereo Cliffs’. To get there, follow the path drawn in the map at the back of this letter. This will be a nice little adventure for you as I know you love wondering around through nature. I hope you find the gift and return to your mother safely using the skills you learned at school. And I look forward to reunite with you both soon.</br>"+
"Your yearning father,<br>"+
"Sami'<br>"+
"Majd flipped the letter with excitement to see the map his dad has drawn for him. Then, looking at Dalia she saw a smile on his mother face before she said ‘Better get ready if you want to start your journey early tomorrow’. Majd jumped to his room, packed some camping gear and necessities while in her mind already thinking of his father and the gift that awaits at the end of the adventure.</span>";
 
    let infoTagF = "<span>Once upon a time, there lived a young girl with her mother on the outskirts of a small and peaceful village called Tomako. On a clear day early in the summer, Dalia, Majd’s mother, was preparing a cake for Majd’s birthday when the mail arrived with a bunch of letters. Majd sifted through the advertisements to pick up one special envelope addressed to her by name. Dalia asked Majd to open the envelope carefully and read it out loud. Majd did so, and read:</br>"+ 
"'My beloved Majd,"+
"It has been two years since we last celebrated your birthday together. You, your mom, and I. I am getting my work finished and can’t wait to see you both again. I still have that wool necklace that you made for me to keep me safe. I wear it all the time. Unfortunately, I am not going to make it in time for your birthday. However, I have a gift for you stashed in a chest under ‘The Sheereo Cliffs’. To get there, follow the path drawn in the map at the back of this letter. This will be a nice little adventure for you as I know you love wondering around through nature. I hope you find the gift and return to your mother safely using the skills you learned at school. And I look forward to reunite with you both soon.</br>"+
"Your yearning father,<br>"+
"Sami'<br>"+
"Majd flipped the letter with excitement to see the map her dad has drawn for  her. Then, looking at Dalia  she saw a smile on her mother face before she said ‘Better get ready if you want to start your journey early tomorrow’. Majd jumped to her room, packed some camping gear and necessities while in her mind already thinking of  her father and the gift that awaits at the end of the adventure.</span>";
 
    infoText.innerHTML = infoTag;
    infoTextF.innerHTML = infoTagF;
}

// if exitQuiz button clicked
exit_btn.onclick = ()=>{
    //window.location="login.php";
    document.getElementById("info_box").classList.remove("activeInfo"); //hide info box
	start_btn.style.display = "block";
}

const restart_quiz = result_box.querySelector(".buttons .restart");
const quit_quiz = result_box.querySelector(".buttons .quit");

// if restartQuiz button clicked
restart_quiz.onclick = ()=>{
    quiz_box.classList.add("activeQuiz"); //show quiz box
    result_box.classList.remove("activeResult"); //hide result box
    widthValue = 0;
    clearInterval(counter); //clear counter
    clearInterval(counterLine); //clear counterLine
    next_btn.classList.remove("show"); //hide the next button
}

// if quitQuiz button clicked
quit_quiz.onclick = ()=>{
    //window.location.reload(); //reload the current window
    window.location="login.php";
    
}

const next_btn = document.querySelector("footer .next_btn");
const bottom_ques_counter = document.querySelector("footer .total_que");

// creating the new div tags which for icons
let tickIconTag = '<div class="icon tick"><i class="fas fa-check"></i></div>';
let crossIconTag = '<div class="icon cross"><i class="fas fa-times"></i></div>';

function playMusicCorrect(){
  var music = new Audio('music/correct.mp3');
  music.play();
  }
 function playMusicFalse(){
  var music = new Audio('music/false.mp3');
  music.play();
  }


function showResult(){
    info_box.classList.remove("activeInfo"); //hide info box
    quiz_box.classList.remove("activeQuiz"); //hide quiz box
	//hideAll();								 // hide all levels
    result_box.classList.add("activeResult"); //show result box
    const scoreText = result_box.querySelector(".score_text");
    let scoreTag = '<span>‘I see you have found it’. Majd turned around to see who said that. He found that it was the mysterious man with the mask and the red sweater. The man then took off his sun glasses then his mask. Majd’s face brightened, he stood up and ran with tears flowing down his and embraced Sami in a passionate hug. While his father held Majd off the ground, he heard his kid whisper to him ‘It was you all along! This is the best gift ever dad’ and Sami wondered which gift Majd meant.</p></span>';
    scoreText.innerHTML = scoreTag;  //adding new span tag inside score_Text
   
}
function showResultF(){
    info_box.classList.remove("activeInfo"); //hide info box
    quiz_box.classList.remove("activeQuiz"); //hide quiz box
	//hideAll();								 // hide all levels
    result_box.classList.add("activeResult"); //show result box
    const scoreText = result_box.querySelector(".score_text");
    let scoreTag = '<span>‘I see you have found it’. Majd turned around to see who said that. She found that it was the mysterious man with the mask and the red sweater. The man then took off his sun glasses then his mask. Majd’s face brightened, she stood up and ran with tears flowing down her and embraced Sami in a passionate hug. While his father held Majd off the ground, she heard his kid whisper to him ‘It was you all along! This is the best gift ever dad’ and Sami wondered which gift Majd meant.</p></span>';
    scoreText.innerHTML = scoreTag;  //adding new span tag inside score_Text
   
}