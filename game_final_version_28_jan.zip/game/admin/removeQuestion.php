<?php
include('../db/dbcon.php');
include('session.php');
if($user_username =="admin"){
    
    
if(isset($_POST['ques_id'])){

$ques_id=$_POST['ques_id'];

/***************** Get Order of Question *****************/

$query=mysqli_query($conn,"select * from questions where ques_id=$ques_id" )or die('Nothing to Display');
$row= mysqli_fetch_array($query);
$num=mysqli_num_rows($query);

$isFinal =$row['is_final_ques'];
$part=$row['level_part'];
$prev_ques_id=$row['prev_ques_id'];
$next_ques_id=$row['next_ques_id'];
    if($isFinal==1){
        mysqli_query($conn,"update questions set next_ques_id = 0 , is_final_ques = 1 where ques_id = $prev_ques_id ");
        
    }
    //Not Final Level, it is inserted between 2 levels
    else{
    mysqli_query($conn,"update questions set next_ques_id = $next_ques_id  where ques_id = $prev_ques_id ");
    mysqli_query($conn,"update questions set prev_ques_id = $prev_ques_id  where ques_id = $next_ques_id ");
    }


/************************************************/






$stmt = $conn->prepare("Delete from questions where ques_id=$ques_id ")or die('Error, query failed');

$stmt->execute();
$conn->close();
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
}

}
?>