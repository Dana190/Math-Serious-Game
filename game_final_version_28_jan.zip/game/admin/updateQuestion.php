<?php
include('../db/dbcon.php');
include('session.php');
if($user_username =="admin"){
    $ques_id=$_POST['ques_id'];
    
if(isset($_POST['storyM'])){

$storyM = $_POST['storyM'];
$storyF = $_POST['storyF'];
$storyM_hard = $_POST['storyM_hard'];
$storyF_hard = $_POST['storyF_hard'];
$stmt = $conn->prepare("update questions set storyM = ? , storyF =? ,storyM_hard = ? , storyF_hard =? where ques_id=$ques_id ")or die('Error, query failed');
		
$stmt->bind_param("ssss",$storyM,$storyF,$storyM_hard,$storyF_hard);
$stmt->execute();
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
}

else if(isset($_POST['questionM'])){

$questionM = $_POST['questionM'];
$questionF = $_POST['questionF'];
$choices= $_POST['choices'];
$answer= $_POST['answer'];
$questionM_hard = $_POST['questionM_hard'];
$questionF_hard = $_POST['questionF_hard'];
$choices_hard= $_POST['choices_hard'];
$answer_hard= $_POST['answer_hard'];
$hint=$_POST['hint'];
$stmt = $conn->prepare("update questions set questionM = ? , questionF =? , choices= ? , answer= ? ,
questionM_hard = ? , questionF_hard =? , choices_hard= ? , answer_hard= ?,hint= ? where ques_id=$ques_id ")or die('Error, query failed');
		
$stmt->bind_param("sssisssis",$questionM,$questionF,$choices,$answer,$questionM_hard,$questionF_hard,$choices_hard,$answer_hard,$hint);
$stmt->execute();
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);    
}

}
?>