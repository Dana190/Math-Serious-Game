<?php
if (!isset($_SESSION)) {
session_start(); 
}
include "../db/dbcon.php";
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) { ?>
<script>
window.location = "../login.php";
</script>
<?php
}else {
$session_id=$_SESSION['id'];
$query= mysqli_query($conn,"select * from users where user_id = '$session_id'");
$row = mysqli_fetch_array($query);
$user_username = $row['username'];

}
?>