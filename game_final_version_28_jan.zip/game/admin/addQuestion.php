<?php
include('../db/dbcon.php');
include('session.php');
if($user_username =="admin"){
    
$level=$_POST["level"];
$level_part=0;
$prev_ques_id=0;
$next_ques_id=0;
$is_final_ques=0;
//Check level is valid or Not:
$q=mysqli_query($conn,"select * from questions ORDER BY level DESC LIMIT 1" )or die('Nothing to Display');
$r= mysqli_fetch_array($q);
$last_level=$r["level"];
if($level > ($last_level+1)){
  $response['status'] = 'invalidLevel';
header('Content-type: application/json');
echo json_encode($response);    
}
else{
/***************** Get Order of Question *****************/

$query=mysqli_query($conn,"select * from questions where level=$level ORDER BY level_part DESC LIMIT 1" )or die('Nothing to Display');
$row= mysqli_fetch_array($query);
$num=mysqli_num_rows($query);
if($num>0){
    $isFinal =$row['is_final_ques'];
    $part=$row['level_part'];
    if($isFinal==1){
        $is_final_ques=1;
        $next_ques_id=0;
        $prev_ques_id=$row['ques_id'];
        $level_part=(int)$part+1;
        
    }
    //Not Final Level, it is inserted between 2 levels
    else{
    $is_final_ques=0;
    $level_part=(int)$part+1;
    $prev_ques_id=$row['ques_id'];
    $next_ques_id=$row['next_ques_id'];
    }
}
//else New Level is created
else{
    $is_final_ques=1;
    $level_part=0;
    $next_ques_id=0;
    
    //Still Previous ID:
    $prev_level=$level-1;
    $query2=mysqli_query($conn,"select * from questions where level=$prev_level ORDER BY level_part DESC LIMIT 1" )or die('Nothing to Display');
    $row2= mysqli_fetch_array($query2);
    
    $prev_ques_id=$row2["ques_id"];
    
    //Now update previous level $prev_level
    
}
/************************************************/
if(isset($_POST['storyM'])&& isset($_POST['storyM_hard'])){    

$storyM = $_POST['storyM'];
$storyF = $_POST['storyF'];
$choices=$_POST["choices"];
$answer=$_POST["answer"];
//hard:
$storyM_hard = $_POST['storyM_hard'];
$storyF_hard = $_POST['storyF_hard'];
$choices_hard=$_POST["choices_hard"];
$answer_hard=$_POST["answer_hard"];

$hint=$_POST["hint"];
$questionM="";
$questionF="";
$questionM_hard="";
$questionF_hard="";

$stmt = $conn->prepare("Insert into questions (level,level_part,storyM , storyF ,questionM ,questionF ,choices,answer,is_final_ques,prev_ques_id,next_ques_id,hint,
storyM_hard,storyF_hard,questionM_hard,questionF_hard,choices_hard,answer_hard) 
Values
(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
")or die('Error, query failed');
		
$stmt->bind_param("iisssssiiiissssssi",$level,$level_part,$storyM,$storyF,$questionM,$questionF,$choices,$answer,$is_final_ques,$prev_ques_id,$next_ques_id,$hint,
$storyM_hard,$storyF_hard,$questionM_hard,$questionF_hard,$choices_hard,$answer_hard
);
$stmt->execute();

//Update Previous Levels:
//In order to do so, we need to get the auto generated is for the new question from database:
$query3=mysqli_query($conn,"select * from questions where level=$level AND storyM='$storyM' AND level_part =$level_part" )or die('Nothing to Display');
$row3= mysqli_fetch_array($query3);
$id=$row3["ques_id"];
if($is_final_ques==1){
    mysqli_query($conn,"update questions set next_ques_id = $id , is_final_ques = 0 where ques_id = $prev_ques_id ");
}
else{
    mysqli_query($conn,"update questions set next_ques_id = $id  where ques_id = $prev_ques_id ");
    mysqli_query($conn,"update questions set prev_ques_id = $id  where ques_id = $next_ques_id ");
}
$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);
}

else if(isset($_POST['questionM']) && isset($_POST['questionM_hard'])){
$level=$_POST["level"];
$questionM = $_POST['questionM'];
$questionF = $_POST['questionF'];
$choices= $_POST['choices'];
$options=implode(",",$choices);
$hint=$_POST["hint"];
$answer= $_POST['answer'];

//hard:
$questionM_hard = $_POST['questionM_hard'];
$questionF_hard = $_POST['questionF_hard'];
$choices_hard=$_POST["choices_hard"];
$options_hard=implode(",",$choices_hard);
$answer_hard=$_POST["answer_hard"];

$storyM="";
$storyF="";
$storyM_hard="";
$storyF_hard="";


$stmt = $conn->prepare("Insert into questions (level,level_part,storyM , storyF ,questionM ,questionF ,choices,answer,is_final_ques,prev_ques_id,next_ques_id,hint,
storyM_hard,storyF_hard,questionM_hard,questionF_hard,choices_hard,answer_hard)
Values
(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) 
")or die('Error, query failed');
		
$stmt->bind_param("iisssssiiiissssssi",$level,$level_part,$storyM,$storyF,$questionM,$questionF,$options,$answer,$is_final_ques,$prev_ques_id,$next_ques_id,$hint,
$storyM_hard,$storyF_hard,$questionM_hard,$questionF_hard,$options_hard,$answer_hard);
$stmt->execute();

//Update Previous Levels:
//In order to do so, we need to get the auto generated is for the new question from database:
$query3=mysqli_query($conn,"select * from questions where level=$level AND questionM='$questionM' AND level_part =$level_part" )or die('Nothing to Display');
$row3= mysqli_fetch_array($query3);
$id=$row3["ques_id"];
if($is_final_ques==1){
    mysqli_query($conn,"update questions set next_ques_id = $id , is_final_ques = 0 where ques_id = $prev_ques_id ");
}
else{
    mysqli_query($conn,"update questions set next_ques_id = $id  where ques_id = $prev_ques_id ");
    mysqli_query($conn,"update questions set prev_ques_id = $id  where ques_id = $next_ques_id ");
}

$response['status'] = 'success';
header('Content-type: application/json');
echo json_encode($response);    
}
else{
  $response['status'] = 'fail';
header('Content-type: application/json');
echo json_encode($response);    
}
}//Checking level

}
?>