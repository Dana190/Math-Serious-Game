<?php 
include('session.php');
include "../db/dbcon.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasure Hunt: Majd's Adventurous Quest to find the Mystery Box</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- FontAweome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="script/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
    <link rel="script/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" />
    <!-- jQuery Ajax Library -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style>
.profile {
  vertical-align: middle;
  width: 150px;
  height: 150px;
  border-radius: 1%;
  border-color: #007bff;
  border-width: 5px;
}
h5{
font-size:16px;
}
body {  
        background:lightblue;
        background-image: url('../images/bg5.png');
        height: 100%;
        width:100%;
        background-position: center;
        background-size:cover;
       
 }
  .hiddenChoice{
     display:none;
 }
 .activeChoice{
     display:block;
 }
  .activeChoice_h{
     display:block;
 }
 .zero,.two,.three,.four{
     margin-left:10px;
 }
    </style>
    
</head>
<body>

	
<form id="quiz-form" class="quiz-form" style="display:block">

<div class='quiz_box align-items-center activeQuiz justify-content-center' id="options"; >
<header>
            <div class='title'>Insert New Challenge </div>           
</header>
        <section>   <tr>
            <td> Insert a new Challenge after </td>
            <?php 
           
            $levels = array();
            $result=mysqli_query($conn,"select * from questions ORDER BY level" )or die('Nothing to Display');
            while($row = mysqli_fetch_assoc($result)) {
                    $levels[] = $row['level'];
                }
            
            $levels=array_unique($levels);
            $levels = array_values($levels);
            $prev_level=$levels[0];
            $next_level=$levels[1];
            ?>

            <td> <select name="previous_level" id="previous_level" >
            
            <?php
            for($i=$prev_level;$i<count($levels);$i++){
                
                echo "<option value=".$i.">".$i."</option>";
                
            }
            
            ?>
            </select>
            
            </td>
            </tr>
            <br>      
                <div class='question bg-white p-3 border-bottom'>
                    
                    <div class='d-flex flex-row align-items-center question-title' >                    
     <tr><td><textarea  rows='3' cols='30' name='textM' >Easy Version For Male Character ...</textarea></td>
     <td><textarea  rows='3' cols='30' name='textF' >Easy Version For Female Character ...</textarea></td></tr>
                  
                   
                  </div>
                  <br>
                  <div class='d-flex flex-row align-items-center question-title' >                    
     <tr><td><textarea  rows='3' cols='30' name='textM_hard' >Hard Version For Male Character ...</textarea></td>
     <td><textarea  rows='3' cols='30' name='textF_hard' >Hard Version For Female Character ...</textarea></td></tr>
     
                 
                  </div>
                <center><div><tr><td><img src='../images/hint.png' width='40px' height='40px'></td></tr><tr><td><textarea  rows='1' cols='25' name='hint' value='No Hint Provided!' >No Hint Provided! </textarea></td></tr>
                   </div></center>
                <br>
                <table>
                    <tr>
                        <td><p>Number of Choices: </p></td>
                        <td><input type="button" class='btn btn-primary d-flex align-items-center  btn-success zero' style="width: 30px;"  value="0"/> </td>
                        
                        <td><input type="button" class='btn btn-primary d-flex align-items-center  btn-success two' style="width: 30px;"  value="2"/> </td>
                        
                 <td><input type="button" class='btn btn-primary d-flex align-items-center  btn-success three' style="width: 30px;"  value="3"/> </td>
                 
                  <td><input type="button" class='btn btn-primary d-flex align-items-center  btn-success four' style="width: 30px;"  value="4"/></td>
                  </tr>
                  </table>
                <br>
                <!-- 4 Choices are all Hidden till User choose number of choices -->
                 <div class='d-flex flex-row ' > 
                 
                  <div>
                  
                  <div class="ans ml-2 hiddenChoice" id="choice1">
                  <h5> Choices for Easy Version</h5>
                        <input type="radio" name='radio' id='0' value='0' checked> 
                       <input type="text" name="choice1"   value="" >
                    </div>
                     <div class="ans ml-2 choice2 hiddenChoice" id="choice2">
                        <input type="radio" name='radio' id='1' value='1' > 
                       <input type="text" name="choice2"  value="" >
                    </div>
                     <div class="ans ml-2 choice3 hiddenChoice" id="choice3">
                        <input type="radio" name='radio' id='2' value='2' > 
                       <input type="text" name="choice3"  value="" >
                    </div>
                     <div class="ans ml-2 choice4 hiddenChoice" id="choice4" >
                        <input type="radio" name='radio' id='3' value='3' > 
                       <input type="text" name="choice4"   value="" >
                    </div>
                    </div>
                    <div>
                <div class="ans ml-2 hiddenChoice" id="choice1_h">
                <h5> Choices for Hard Version</h5>
                        <input type="radio" name='radio_hard' id='0' value='0' checked> 
                       <input type="text" name="choice1_h"   value="" >
                    </div>
                     <div class="ans ml-2 choice2_h hiddenChoice" id="choice2_h">
                        <input type="radio" name='radio_hard' id='1' value='1' > 
                       <input type="text" name="choice2_h"  value="" >
                    </div>
                     <div class="ans ml-2 choice3_h hiddenChoice" id="choice3_h">
                        <input type="radio" name='radio_hard' id='2' value='2' > 
                       <input type="text" name="choice3_h"  value="" >
                    </div>
                     <div class="ans ml-2 choice4_h hiddenChoice" id="choice4_h" >
                        <input type="radio" name='radio_hard' id='3' value='3' > 
                       <input type="text" name="choice4_h"   value="" >
                    </div>
</div>
                    </div>
                    <input type="button" class='btn btn-primary d-flex align-items-center btn-success add' style="width: 200px;"  value="Add Question/Story"/>
        </section>
        
        </div></form>
<script>
			jQuery(document).ready(function($){
			    	$('.add').click(function() {
			    	    let count=0;
			    	    let choices=[];
			    	    $('.activeChoice').each(function(){
				       count++;
				       choices.push($("input[name=choice"+count+"]").val());

                        });

                    //hard version:
                        let count2=0;
			    	    let choices_hard=[];
			    	    $('.activeChoice_h').each(function(){
				       count2++;
				       choices_hard.push($("input[name=choice"+count2+"_h]").val());

                        });


                    var answer=$("input[name=radio]:checked").val();
                    //hard version:
                    var answer_hard=$("input[name=radio_hard]:checked").val();

                    var level=+ $("#previous_level").val()+1;
                    var textM=$("textarea[name=textM]").val();
				    var textF=$("textarea[name=textF]").val();
                    var textM_hard=$("textarea[name=textM_hard]").val();
				    var textF_hard=$("textarea[name=textF_hard]").val();
                    var hint=$("textarea[name=hint]").val();

				    //Remove , from textF and textM to prevent confusion of DB array
				    if (choices==""){
	                    $.ajax({
						type: "POST",
						url: "insertQuestionDB.php",
						dataType: "json",
						data: {"storyM":textM,"storyF":textF,"level":level,"choices":"","answer":0,"storyM_hard":textM_hard,"storyF_hard":textF_hard,"choices_hard":"","answer_hard":0,"hint":"No Hint Provided!"},
						success: function(data){
						    if(data.status=="invalidLevel"){
						       alert("Please Choose a Valid Level");
						    }
						else alert("Successfully Added Story Level");
						},
						error: function(data, textStatus, jqXHR) {
 alert(data.status);
}
				    });
	               }
	               else{
	                    $.ajax({
						type: "POST",
						url: "insertQuestionDB.php",
						dataType: "json",
						data: {"questionM":textM,"questionF":textF,"level":level,"choices":choices,
                        "answer":answer,"questionM_hard":textM_hard,"questionF_hard":textF_hard,"choices_hard":choices_hard,"answer_hard":answer_hard,
                        "hint":hint},
						success: function(data){
						     if(data.status=="invalidLevel"){
						        alert("Please Choose a Valid Level");
						    }
						else 
						alert("Successfully Added Question ");
						},
						error: function(data) {
                        alert(data.status);
                        }
				    });
	               }
                });

			   	$('.zero').click(function() {
				    document.getElementById("choice1").classList.add("hiddenChoice");
				    document.getElementById("choice2").classList.add("hiddenChoice");
				    document.getElementById("choice3").classList.add("hiddenChoice");
				    document.getElementById("choice4").classList.add("hiddenChoice");
                    
                    document.getElementById("choice1_h").classList.add("hiddenChoice");
				    document.getElementById("choice2_h").classList.add("hiddenChoice");
				    document.getElementById("choice3_h").classList.add("hiddenChoice");
				    document.getElementById("choice4_h").classList.add("hiddenChoice");
				    
				    document.getElementById("choice1").classList.remove("activeChoice");
				    document.getElementById("choice2").classList.remove("activeChoice");
				    document.getElementById("choice3").classList.remove("activeChoice");
				    document.getElementById("choice4").classList.remove("activeChoice");

                    document.getElementById("choice1_h").classList.remove("activeChoice_h");
				    document.getElementById("choice2_h").classList.remove("activeChoice_h");
				    document.getElementById("choice3_h").classList.remove("activeChoice_h");
				    document.getElementById("choice4_h").classList.remove("activeChoice_h");
                 });
				$('.two').click(function() {
				    document.getElementById("choice1").classList.remove("hiddenChoice");
				    document.getElementById("choice2").classList.remove("hiddenChoice");
				    document.getElementById("choice1_h").classList.remove("hiddenChoice");
				    document.getElementById("choice2_h").classList.remove("hiddenChoice")

				    document.getElementById("choice1").classList.add("activeChoice");
				    document.getElementById("choice2").classList.add("activeChoice");
				    document.getElementById("choice1_h").classList.add("activeChoice_h");
				    document.getElementById("choice2_h").classList.add("activeChoice_h");

				    document.getElementById("choice3").classList.add("hiddenChoice");
				    document.getElementById("choice4").classList.add("hiddenChoice");
                    document.getElementById("choice3_h").classList.add("hiddenChoice");
				    document.getElementById("choice4_h").classList.add("hiddenChoice");
				    
				    document.getElementById("choice3").classList.remove("activeChoice");
				    document.getElementById("choice4").classList.remove("activeChoice");
                    document.getElementById("choice3_h").classList.remove("activeChoice_h");
				    document.getElementById("choice4_h").classList.remove("activeChoice_h");
                 });
                 $('.three').click(function() {
                    document.getElementById("choice1").classList.remove("hiddenChoice");
				    document.getElementById("choice2").classList.remove("hiddenChoice");
				    document.getElementById("choice3").classList.remove("hiddenChoice");
				    
                    document.getElementById("choice1_h").classList.remove("hiddenChoice");
				    document.getElementById("choice2_h").classList.remove("hiddenChoice");
				    document.getElementById("choice3_h").classList.remove("hiddenChoice");

                    document.getElementById("choice1").classList.add("activeChoice");
                    document.getElementById("choice2").classList.add("activeChoice");
                    document.getElementById("choice3").classList.add("activeChoice");
                    document.getElementById("choice1_h").classList.add("activeChoice_h");
                    document.getElementById("choice2_h").classList.add("activeChoice_h");
                    document.getElementById("choice3_h").classList.add("activeChoice_h");

				    document.getElementById("choice4").classList.add("hiddenChoice");
				    document.getElementById("choice4_h").classList.add("hiddenChoice");

				    document.getElementById("choice4").classList.remove("activeChoice");
                    document.getElementById("choice4_h").classList.remove("activeChoice_h");
                    });
                 $('.four').click(function() {
                document.getElementById("choice1").classList.remove("hiddenChoice");
				document.getElementById("choice2").classList.remove("hiddenChoice");
				document.getElementById("choice3").classList.remove("hiddenChoice");
				document.getElementById("choice4").classList.remove("hiddenChoice");
                document.getElementById("choice1_h").classList.remove("hiddenChoice");
				document.getElementById("choice2_h").classList.remove("hiddenChoice");
				document.getElementById("choice3_h").classList.remove("hiddenChoice");
				document.getElementById("choice4_h").classList.remove("hiddenChoice");

                document.getElementById("choice1").classList.add("activeChoice");
                document.getElementById("choice2").classList.add("activeChoice");
                document.getElementById("choice3").classList.add("activeChoice");
                document.getElementById("choice4").classList.add("activeChoice");
                document.getElementById("choice1_h").classList.add("activeChoice_h");
                document.getElementById("choice2_h").classList.add("activeChoice_h");
                document.getElementById("choice3_h").classList.add("activeChoice_h");
                document.getElementById("choice4_h").classList.add("activeChoice_h");
                });
                 
		});
   
    </script>


</body>
</html>
