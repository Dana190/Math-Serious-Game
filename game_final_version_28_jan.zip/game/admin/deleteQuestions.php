<?php 
include('session.php');
include "../db/dbcon.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasure Hunt: Majd's Adventurous Quest to find the Mystery Box</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- FontAweome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="script/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
    <!-- jQuery Ajax Library -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style>
.profile {
  vertical-align: middle;
  width: 150px;
  height: 150px;
  border-radius: 1%;
  border-color: #007bff;
  border-width: 5px;
}
h5{
font-size:16px;
}
body {  
        background:white;
        /*background-image: url('../images/bg10.png');*/
    
        height: 100%;
        width:100%;
        background-position: center;
        background-size:cover;
       
 }
    </style>
    
</head>
<body>

	
<form id="quiz-form" class="quiz-form" style="display:block">

<?php 
//Get Last Progress First ...

$query = mysqli_query($conn,"select * from questions ORDER BY level") or die('Error, Select query failed');
while($row = mysqli_fetch_array($query)){
    
    $ques_id = $row['ques_id'];
    $level=$row['level'];
    $level_part=$row['level_part'];
    $isFinalQues=$row['is_final_ques'];
    
    $prev_ques=$row['prev_ques_id'];
    $next_ques=$row['next_ques_id'];
    
    $query2 = mysqli_query($conn,"select * from questions where ques_id='$next_ques' Limit 1");
    $row2=mysqli_fetch_array($query2);
    $next_level=$row2["level"];

    $query3 = mysqli_query($conn,"select * from questions where ques_id='$prev_ques' Limit 1");
    $row3=mysqli_fetch_array($query3);
    $prev_level=$row3["level"];    
 
    $questionM=$row['questionM'];
    $storyM=$row['storyM'];
 
    $questionF=$row['questionF'];
    $storyF=$row['storyF'];

    
    $choices=$row['choices'];
    $array_choices = explode(',', $choices);
    $answer=$row['answer'];

echo "<div class='quiz_box  align-items-center justify-content-center'  id='quiz_box"; echo $ques_id; echo "' >

        <section>         
        
                <div class='question bg-white p-3 border-bottom'>
                <h4>
            <div class='title'>Level $level </div>           
</h4>
                    <div class='d-flex flex-row align-items-center question-title'>                    
                        <h5 class='mt-1 ml-2'>";
$isStory=false;
if($storyM!=""){
    $isStory=true;
    echo "<tr><td><textarea  rows='6' cols='50' name='$ques_id";echo "M' value='$storyM' >$storyM</textarea></td>";
    echo "<td><textarea  rows='6' cols='50' name='$ques_id";echo "F' value='$storyF' >$storyF</textarea></td></tr>";
}
else  {
    echo "<tr><td><textarea  rows='6' cols='50' name='$ques_id";echo "M' value='$questionM' >$questionM</textarea></td>";
    echo "<td><textarea  rows='6' cols='50' name='$ques_id";echo "F' value='$questionF' >$questionF</textarea></td></tr>";
}

echo "</h5>
                    </div>";
                 if($choices!=""){ 
                    for($i=0;$i<count($array_choices);$i++){
                  
           echo "<div class='ans ml-2'>
                        <label class='radio'> <input type='radio' name='radio"; echo $ques_id; echo "' id='"; echo $ques_id; echo "' value='$i' ";
                        if($answer == $i) echo "checked"; echo "
                        > <span>";
                       echo "
                        </label>
                        <label class='radio'> <input type='text' name='"; echo $ques_id; echo "$i' id='"; echo $ques_id; echo "' value='$array_choices[$i]' > ";
                        echo "
                        </label></span>
                    </div>";
                  
                   
                    }
                   } 
               echo " </div>
                <div class='d-flex flex-row justify-content-between align-items-center p-3 bg-white'> ";
               
                echo "<button class='btn btn-primary border-success align-items-center btn-success delete' data-quesid='";echo $ques_id; echo "' onclick='' type='button' ><i class='fa fa-trash ml-2'></i> Delete Above Question </button>";
                 
                echo "</div>
        </section>
</div>";
}

?>
</form>


  
    <!-- Next Question,Previous Question, Calculate Result & Send it to php-->
    <script>
			jQuery(document).ready(function($){
				$('.delete').click(function() {
				    var elem = $(this);
				    var id=elem.attr('data-quesid');
				    /*****************************/
				   
	                    $.ajax({
						type: "POST",
						url: "removeQuestion.php",
						dataType: "json",
						data: {"ques_id":id},
						success: function(data){
						alert("Successfully Removed Question "+id);
						},
						error: function() {
                        alert("Error Connecting Database!");
                        }
				    });
	                      });
		});

   
    </script>


</body>
</html>
