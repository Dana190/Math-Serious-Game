<?php 
include('session.php');
include "../db/dbcon.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasure Hunt: Majd's Adventurous Quest to find the Mystery Box</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <!-- FontAweome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="script/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
    <link rel="script/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" />
    <!-- jQuery Ajax Library -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style>
.profile {
  vertical-align: middle;
  width: 150px;
  height: 150px;
  border-radius: 1%;
  border-color: #007bff;
  border-width: 5px;
}
h5{
font-size:16px;
}
body {  
        background:white;
        /*background-image: url('../images/bg.png');*/
        height: 100%;
        width:100%;
        background-position: center;
        background-size:cover;
       
 }
    </style>
    
</head>
<body>

	
<form id="quiz-form" class="quiz-form" style="display:block">

<?php 
//Get Last Progress First ...

$query = mysqli_query($conn,"select * from questions ORDER BY level") or die('Error, Select query failed');
while($row = mysqli_fetch_array($query)){
    
    $ques_id = $row['ques_id'];
    $level=$row['level'];
    $level_part=$row['level_part'];
    $isFinalQues=$row['is_final_ques'];
    if(isset($row['hint']) && $row['hint']!= ""){
        $hint=$row['hint'];
    }
    else $hint="No Hint Provided!";
    $prev_ques=$row['prev_ques_id'];
    $next_ques=$row['next_ques_id'];
    
    $query2 = mysqli_query($conn,"select * from questions where ques_id='$next_ques' Limit 1");
    $row2=mysqli_fetch_array($query2);
    $next_level=$row2["level"];

    $query3 = mysqli_query($conn,"select * from questions where ques_id='$prev_ques' Limit 1");
    $row3=mysqli_fetch_array($query3);
    $prev_level=$row3["level"];    
 
    $questionM=$row['questionM'];
    $storyM=$row['storyM'];
    $questionM_hard=$row['questionM_hard'];
    $storyM_hard=$row['storyM_hard'];

    $questionF=$row['questionF'];
    $storyF=$row['storyF'];
    $questionF_hard=$row['questionF_hard'];
    $storyF_hard=$row['storyF_hard'];
    
    $choices=$row['choices'];
    $array_choices = explode(',', $choices);
    $answer=$row['answer'];
    $choices_hard=$row['choices_hard'];
    $array_choices_hard = explode(',', $choices_hard);
    $answer_hard=$row['answer_hard'];
echo "<div class='quiz_box align-items-center justify-content-center'  id='quiz_box"; echo $ques_id; echo "' >

        <section>         

                <div class='question bg-white p-3 border-bottom'>        <h4>
            <div class='title'>Level $level </div>           
</h4>
                    <div class='d-flex flex-row align-items-center question-title'>                    
                        <h5 class='mt-1 ml-2'>";
$isStory=false;
if($storyM!=""){
    $isStory=true;
    echo "<div>Easy Version </div>";
    echo "<tr><td><textarea  rows='3' cols='50' name='$ques_id";echo "M' value='$storyM' >$storyM</textarea></td>";
    echo "<td><textarea  rows='3' cols='50' name='$ques_id";echo "F' value='$storyF' >$storyF</textarea></td></tr>";
    echo "<br>";
    echo "<div>Hard Version </div>";
    echo "<tr><td><textarea  rows='3' cols='50' name='$ques_id";echo "M_hard' value='$storyM_hard' >$storyM_hard</textarea></td>";
    echo "<td><textarea  rows='3' cols='50' name='$ques_id";echo "F_hard' value='$storyF_hard' >$storyF_hard</textarea></td></tr>";
}
else  {
    echo "<div>Easy Version </div>";
    echo "<tr><td><textarea  rows='3' cols='50' name='$ques_id";echo "M' value='$questionM' >$questionM</textarea></td>";
    echo "<td><textarea  rows='3' cols='50' name='$ques_id";echo "F' value='$questionF' >$questionF</textarea></td></tr>";
    echo "<br>";
    echo "<div>Hard Version </div>";
    echo "<tr><td><textarea  rows='3' cols='50' name='$ques_id";echo "M_hard' value='$questionM_hard' >$questionM_hard</textarea></td>";
    echo "<td><textarea  rows='3' cols='50' name='$ques_id";echo "F_hard' value='$questionF_hard' >$questionF_hard</textarea></td></tr>";
    echo "<br><tr><td><img src='../images/hint.png' width='40px' height='40px'></td></tr><tr><td><textarea  rows='1' cols='50' name='$ques_id";echo "Hint' value='$hint' >$hint</textarea></td></tr>";
}

echo "</h5>
                    </div>
                 
                  ";
                 /****Choice ***/
                if($choices!=""){ 
                    echo "<div class='d-flex flex-row ' > 
                 
                  <div>
                   <h6> Easy Version </h6>
                  ";
                    for($i=0;$i<count($array_choices);$i++){
                  
           echo "<div class='ans ml-2' >
          
                        <label class='radio'> <input type='radio' name='radio"; echo $ques_id; echo "' id='"; echo $ques_id; echo "' value='$i' ";
                        if($answer == $i) echo "checked"; echo "
                        > <span>";
                       echo "
                        </label>
                        <label class='radio'> <input type='text' name='"; echo $ques_id; echo "$i' id='"; echo $ques_id; echo "' value='$array_choices[$i]' > ";
                        echo "
                        </label></span>
                    </div>
                   ";
            
                    }
                  
                echo "</div><div><h6> Hard Version </h6>";

                    for($i=0;$i<count($array_choices);$i++){
                  
           echo "<div class='ans ml-2'>
           
                        <label class='radio'> <input type='radio' name='radio"; echo $ques_id; echo "_hard' id='"; echo $ques_id; echo "_hard' value='$i' ";
                        if($answer_hard == $i) echo "checked"; echo "
                        > <span>";
                       echo "
                        </label>
                        <label class='radio'> <input type='text' name='hard_"; echo $ques_id; echo "$i' id='"; echo $ques_id; echo "_hard' value='$array_choices_hard[$i]' > ";
                        echo "
                        </label></span>
                    </div>";
                  
                   
                    }
                   echo "</div></div>";
                   } 


                 /**************/
               echo " </div>
                <div class='d-flex flex-row justify-content-between align-items-center p-3 bg-white'> ";
               
                echo "<button class='btn btn-primary border-success align-items-center btn-success next' data-numChoices='";echo count($array_choices); echo "' data-levelid='";echo $next_level; echo "' data-quesid='";echo $ques_id; echo "' data-artid='";echo $next_ques; echo "' onclick='' data-isStory='";echo $isStory; echo "' type='button' ><i class='fa fa-save ml-2'></i> Apply Edits </button>";
                 
                echo "</div>
        </section>
</div>";
}

?>
</form>


  
    <!-- Next Question,Previous Question, Calculate Result & Send it to php-->
    <script>
			jQuery(document).ready(function($){
			   
				$('.next').click(function() {
				    var elem = $(this);
				    var level=elem.attr('data-levelid');
				    var id=elem.attr('data-quesid');
				    var next=elem.attr('data-artid');
				    var next_id="quiz_box"+elem.attr('data-artid');
				    var prev_id="quiz_box"+(parseInt(elem.attr('data-artid'))-1).toString();
				    var isStory=elem.attr('data-isStory');
				    var textM=$("textarea[name="+id+"M]").val();
				    var textF=$("textarea[name="+id+"F]").val();
                    var textM_hard=$("textarea[name="+id+"M_hard]").val();
				    var textF_hard=$("textarea[name="+id+"F_hard]").val();
                    var hint=$("textarea[name="+id+"Hint]").val();
				    /*****************************/
				   if (isStory){
	                    $.ajax({
						type: "POST",
						url: "updateQuestion.php",
						dataType: "json",
						data: {"ques_id":id,"storyM":textM,"storyF":textF,"storyM_hard":textM_hard,"storyF_hard":textF_hard},
						success: function(data){
						alert("Successfully Updated Question "+id);
						},
						error: function() {
                        alert("Error Connecting Database!");
                        }
				    });
	               }
	             else{
	                var answer=$("input[name=radio"+id+"]:checked").val();
	                var answer_hard=$("input[name=radio"+id+"_hard]:checked").val();

	                var num_choices=elem.attr('data-numChoices');
	                var choice0=$("input[name="+id+"0]").val();
				    var choice1=$("input[name="+id+"1]").val();
				    var choice2=$("input[name="+id+"2]").val();
				    var choice3=$("input[name="+id+"3]").val();
				    var choices="";
				    if(num_choices==2){
				    choices=choice0+","+choice1;
				    }
				    else if(num_choices==3){
				    choices=choice0+","+choice1+","+choice2;
				    }else if(num_choices==4){
				        choices=choice0+","+choice1+","+choice2+","+choice3;
				    }

                    //Hard Choices:
                    
                    var choice0_hard=$("input[name=hard_"+id+"0]").val();
				    var choice1_hard=$("input[name=hard_"+id+"1]").val();
				    var choice2_hard=$("input[name=hard_"+id+"2]").val();
				    var choice3_hard=$("input[name=hard_"+id+"3]").val();
				    var choices_hard="";  
                    if(num_choices==2){
				    choices_hard=choice0_hard+","+choice1_hard;
				    }
				    else if(num_choices==3){
				    choices_hard=choice0_hard+","+choice1_hard+","+choice2_hard;
				    }else if(num_choices==4){
				        choices_hard=choice0_hard+","+choice1_hard+","+choice2_hard+","+choice3_hard;
				    }                 
	                 $.ajax({
						type: "POST",
						url: "updateQuestion.php",
						dataType: "json",
						data: {"ques_id":id,"questionM":textM,"questionF":textF,"choices":choices,"answer":answer,"questionM_hard":textM_hard,"questionF_hard":textF_hard,"choices_hard":choices_hard,"answer_hard":answer_hard,"hint":hint},
						success: function(data){
						alert("Successfully Updated Question "+id);
						},
						error: function() {
                        alert("Error Connecting Database!");
                        }
				    });
	             }
				    /****************************/
				  
            });
		});

   
    </script>
    <!-- Inside this JavaScript file I've coded all Quiz Codes -->
    <script src="js/admin_script.js"></script>
    <!-- Rating Star -->

</body>
</html>
