<?php 
include('session.php');
include "../db/dbcon.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treasure Hunt: Majd's Adventurous Quest to find the Mystery Box</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- FontAweome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="script/javascript" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
    <link rel="script/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" />
    <!-- jQuery Ajax Library -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style>
.profile {
  vertical-align: middle;
  width: 150px;
  height: 150px;
  border-radius: 1%;
  border-color: #007bff;
  border-width: 5px;
}
h5{
font-size:16px;
}
body {  
        background:lightblue;
        background-image: url('../images/bg10-min.jpg');
        height: 100%;
        width:100%;
        background-position: center;
        background-size:cover;
       
 }
    </style>
    
</head>
<body>

	
<form id="quiz-form" class="quiz-form" style="display:block">

<div class='quiz_box align-items-center activeQuiz justify-content-center' id="options"; >
<header>
            <div class='title'>Admin Dashboard </div>           
</header>
        <section>         
                <div class='question bg-white p-3 border-bottom'>
         
<div class='d-flex flex-row align-items-center question-title' style="margin-top:10px">
<input type="button" class='btn btn-primary d-flex align-items-center btn-danger' style="width: 300px;" onclick="window.location.href='addQuestions.php';" value="Add Challenge"/>
</div>
<div class='d-flex flex-row align-items-center question-title' style="margin-top:10px">
<input type="button" class='btn btn-primary d-flex align-items-center btn-danger' style="width: 300px;" onclick="window.location.href='insertQuestion.php';" value="Insert Challenge"/>
</div>
<div class='d-flex flex-row align-items-center question-title' style="margin-top:10px">      
<input type="button" class='btn btn-primary d-flex align-items-center btn-danger' style="width: 300px;" onclick="window.location.href='editQuestions.php';" value="Edit Challenge"/>
</div>

<div class='d-flex flex-row align-items-center question-title' style="margin-top:10px">
<input type="button" class='btn btn-primary d-flex align-items-center btn-danger' style="width: 300px;" onclick="window.location.href='deleteQuestions.php';" value="Remove Challenge"/>
</div>
            
                  
                   
                  </div>
               
        </section>
</div>


</body>
</html>
